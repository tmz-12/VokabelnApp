#!/usr/bin/env python3
import fitz
import json
import re
import hashlib
from pathlib import Path
from collections import Counter, defaultdict

SOURCE = Path('/mnt/data/Aspekte_neu_C1_Complete_Wortschatz_DE_EN_ZH-TW_plus_C2_verified(1).pdf')
OUT = Path('/mnt/data/aspekte_neu_c1_c2_vocabulary.json')
REPORT = Path('/mnt/data/aspekte_neu_c1_c2_import_report.json')

EXPECTED_C1_TOTAL = 3270
EXPECTED_C2_TOTAL = 180
EXPECTED_KEY_TOTAL = 350
EXPECTED_CHAPTERS = 10
EXPECTED_C2_PER_CHAPTER = 18
HEADER_C1_COUNTS = {1:396,2:322,3:385,4:418,5:280,6:367,7:340,8:213,9:219,10:329}

# Explicit layout artifacts visible in the source PDF. Raw source text is preserved separately.
LAYOUT_ARTIFACT_FIXES = {
    'gekom- men': 'gekommen',
    'Zusammengehörigkeits- gefühl': 'Zusammengehörigkeitsgefühl',
    'Kommunikationsmanage- ment': 'Kommunikationsmanagement',
    'Präventions- angebote': 'Präventionsangebote',
}

SOURCE_REF_RE = re.compile(r'(?P<ref>\d{1,2}/(?:[A-Z][A-Za-z0-9]*|M\d+)(?:/[A-Za-z0-9]+){0,3})\s*$')
CHAPTER_HEADER_RE = re.compile(r'Kapitel\s+(\d+)')
C2_CHAPTER_RE = re.compile(r'^Kapitel\s+(\d+)\s*·\s*(\d+)\s*C2\s*$')


def normalize_layout_artifacts(s: str) -> str:
    s = s.replace('\u00ad', '')
    s = re.sub(r'[ \t]+', ' ', s).strip()
    for old, new in LAYOUT_ARTIFACT_FIXES.items():
        s = s.replace(old, new)
    return s


def block_rect(block):
    return fitz.Rect(block[0], block[1], block[2], block[3])


def gray_rects(page):
    rects = []
    for d in page.get_drawings():
        fill = d.get('fill')
        if not fill:
            continue
        # Shading used for the 350 key entries is ~#F0F0F0.
        if len(fill) == 3 and all(abs(v - 0.941176) < 0.012 for v in fill):
            rects.append(d['rect'])
    return rects


def overlaps_key(rect: fitz.Rect, shaded):
    area = max(rect.get_area(), 1.0)
    for gr in shaded:
        inter = rect & gr
        if not inter.is_empty and inter.get_area() / area > 0.18:
            return True
    return False


def join_head_lines(lines):
    return normalize_layout_artifacts(' '.join(x.strip() for x in lines if x.strip()))


def extract_source_ref(head: str):
    m = SOURCE_REF_RE.search(head)
    if not m:
        return head.strip(), None
    ref = m.group('ref')
    cleaned = head[:m.start()].rstrip()
    return cleaned, ref


def derive_headword(german: str) -> str:
    # Deterministic display helper only; full source-facing German remains in `german`.
    base = german.strip()
    # Remove parenthetical usage notes from the short front-card label.
    par = base.find(' (')
    if par != -1:
        base = base[:par].rstrip()
    # Remove plural/conjugation tail after the first comma.
    if ',' in base:
        base = base.split(',', 1)[0].rstrip()
    return base


def parse_structured_block(raw_text: str, level: str, chapter, is_key: bool, source_page: int, order: int, rect=None, group_label=None):
    raw_text = raw_text.strip()
    lines = [normalize_layout_artifacts(x) for x in raw_text.splitlines() if x.strip()]
    if level == 'C2' and lines and lines[0].startswith('[C2]'):
        lines[0] = normalize_layout_artifacts(lines[0][4:].strip())

    # Translation starts at the first line containing the EN/ZH separator.
    ti = next((i for i, line in enumerate(lines) if '|' in line), None)
    if ti is None:
        raise ValueError(f'No translation separator on page {source_page}: {raw_text[:120]}')

    pre = lines[:ti]
    trans_first = lines[ti]
    post = lines[ti+1:]

    forms_raw = None
    forms_idx = next((i for i, line in enumerate(pre) if line.startswith('Formen:')), None)
    if forms_idx is not None:
        head_lines = pre[:forms_idx]
        forms_lines = pre[forms_idx:]
        forms_raw = normalize_layout_artifacts(' '.join(forms_lines))
        if forms_raw.startswith('Formen:'):
            forms_raw = forms_raw[len('Formen:'):].strip()
    else:
        head_lines = pre

    german_with_ref = join_head_lines(head_lines)
    german, source_ref = extract_source_ref(german_with_ref)

    en, zh = trans_first.split('|', 1)
    english = normalize_layout_artifacts(en)
    chinese = normalize_layout_artifacts(zh)

    examples = []
    chunks = []
    current_kind = None
    current_idx = None

    # Lines immediately after a trailing '|' belong to the Chinese translation until a marker begins.
    for line in post:
        if line.startswith('★'):
            examples.append(normalize_layout_artifacts(line[1:].strip()))
            current_kind = 'example'
            current_idx = len(examples) - 1
        elif line.startswith('[Chunk]'):
            chunks.append(normalize_layout_artifacts(line[len('[Chunk]'):].strip()))
            current_kind = 'chunk'
            current_idx = len(chunks) - 1
        else:
            if current_kind == 'example' and current_idx is not None:
                examples[current_idx] = normalize_layout_artifacts(examples[current_idx] + ' ' + line)
            elif current_kind == 'chunk' and current_idx is not None:
                chunks[current_idx] = normalize_layout_artifacts(chunks[current_idx] + ' ' + line)
            else:
                chinese = normalize_layout_artifacts((chinese + ' ' + line).strip())

    # Normalize a handful of source-layout artifacts everywhere in derived fields.
    german = normalize_layout_artifacts(german)
    english = normalize_layout_artifacts(english)
    chinese = normalize_layout_artifacts(chinese)
    if forms_raw:
        forms_raw = normalize_layout_artifacts(forms_raw)
    examples = [normalize_layout_artifacts(x) for x in examples]
    chunks = [normalize_layout_artifacts(x) for x in chunks]

    uid_material = f'{level}|{chapter}|{order}|{german}|{source_ref or ""}'
    short_hash = hashlib.sha1(uid_material.encode('utf-8')).hexdigest()[:10]
    if chapter is None:
        entry_id = f'{level.lower()}-unassigned-{order:04d}-{short_hash}'
    else:
        entry_id = f'{level.lower()}-k{chapter:02d}-{order:04d}-{short_hash}'

    return {
        'id': entry_id,
        'level': level,
        'chapter': chapter,
        'groupLabel': group_label or (f'Kapitel {chapter}' if chapter is not None else 'Ohne Kapitelangabe'),
        'orderInChapter': order if chapter is not None else None,
        'orderInGroup': order,
        'headword': derive_headword(german),
        'german': german,
        'english': english or None,
        'traditionalChinese': chinese or None,
        'sourceReference': source_ref,
        'formsRaw': forms_raw,
        'examplesGerman': examples,
        'chunks': chunks,
        'isKey': bool(is_key) if level == 'C1' else False,
        'isC2Upgrade': level == 'C2',
        'sourcePage': source_page,
        'rawText': raw_text,
    }


def merge_split_c1_blocks(page):
    """Yield vocabulary blocks, merging head-only blocks split from their translation block."""
    blocks = page.get_text('blocks')
    shaded = gray_rects(page)
    consumed_prev = set()
    candidates = []

    for i, b in enumerate(blocks):
        txt = b[4].strip()
        if '|' not in txt or txt.startswith('Aspekte neu'):
            continue
        merged_text = txt
        merged_rect = block_rect(b)
        # Some entries have a head in one block and a source-reference/translation in the next.
        first = txt.splitlines()[0].strip() if txt.splitlines() else ''
        if re.match(r'^\d{1,2}/', first) and i > 0:
            pb = blocks[i-1]
            ptxt = pb[4].strip()
            # Only merge plausible head-only text in the same column with a small vertical gap.
            same_col = abs(pb[0] - b[0]) < 8 or abs(pb[2] - b[2]) < 40
            gap = b[1] - pb[3]
            if ptxt and '|' not in ptxt and not ptxt.startswith('Kapitel ') and not ptxt.startswith('Aspekte neu') and len(ptxt) > 2 and same_col and -2 <= gap < 8:
                merged_text = ptxt + '\n' + txt
                merged_rect = block_rect(pb) | merged_rect
                consumed_prev.add(i-1)
        is_key = overlaps_key(merged_rect, shaded)
        candidates.append((i, merged_text, merged_rect, is_key))
    return candidates


def main():
    doc = fitz.open(SOURCE)
    entries = []
    chapter_order = defaultdict(int)
    c1_counts = Counter()
    c1_unassigned = 0
    c2_counts = Counter()
    key_counts = Counter()
    warnings = []
    needs_review = []

    # C1: PDF pages 2-71 (1-indexed); doc indices 1..70.
    for doc_idx in range(1, 71):
        page = doc[doc_idx]
        blocks = page.get_text('blocks')
        if not blocks:
            continue
        hm = CHAPTER_HEADER_RE.search(blocks[0][4])
        if not hm:
            raise RuntimeError(f'No chapter header on PDF page {doc_idx+1}')
        chapter = int(hm.group(1))

        unassigned_marker_idx = next((i for i,b in enumerate(blocks) if b[4].strip() == 'Ohne Kapitelangabe'), None)
        for block_i, raw, rect, is_key in merge_split_c1_blocks(page):
            assigned_chapter = None if (unassigned_marker_idx is not None and block_i > unassigned_marker_idx) else chapter
            group_key = assigned_chapter if assigned_chapter is not None else 'unassigned'
            chapter_order[(group_key, 'C1')] += 1
            order = chapter_order[(group_key, 'C1')]
            e = parse_structured_block(
                raw, 'C1', assigned_chapter, is_key, doc_idx+1, order, rect,
                group_label=(f'Kapitel {assigned_chapter}' if assigned_chapter is not None else 'Ohne Kapitelangabe')
            )
            entries.append(e)
            if assigned_chapter is None:
                c1_unassigned += 1
            else:
                c1_counts[assigned_chapter] += 1
                if is_key:
                    key_counts[assigned_chapter] += 1
            if not e['sourceReference'] and assigned_chapter is not None:
                needs_review.append({
                    'type': 'missingSourceReference',
                    'id': e['id'],
                    'chapter': assigned_chapter,
                    'page': doc_idx+1,
                    'german': e['german'],
                })

    # C2: PDF pages 72-75, doc indices 71..74.
    current_chapter = None
    for doc_idx in range(71, len(doc)):
        page = doc[doc_idx]
        for b in page.get_text('blocks'):
            txt = b[4].strip()
            mh = C2_CHAPTER_RE.match(txt)
            if mh:
                current_chapter = int(mh.group(1))
                declared = int(mh.group(2))
                if declared != EXPECTED_C2_PER_CHAPTER:
                    warnings.append({'type':'c2DeclaredCountUnexpected','page':doc_idx+1,'chapter':current_chapter,'declared':declared})
                continue
            if not txt.startswith('[C2]'):
                continue
            if current_chapter is None:
                raise RuntimeError(f'C2 entry before chapter heading on page {doc_idx+1}')
            chapter_order[(current_chapter, 'C2')] += 1
            order = chapter_order[(current_chapter, 'C2')]
            e = parse_structured_block(txt, 'C2', current_chapter, False, doc_idx+1, order, block_rect(b))
            entries.append(e)
            c2_counts[current_chapter] += 1

    # Sort for app-friendly iteration: chapter, C1 then C2, source order.
    entries.sort(key=lambda e: (e['chapter'] is None, e['chapter'] if e['chapter'] is not None else 999, 0 if e['level']=='C1' else 1, e['orderInGroup']))

    c1_total = sum(c1_counts.values()) + c1_unassigned
    c2_total = sum(c2_counts.values())
    key_total = sum(key_counts.values())

    # Structural validations.
    if c1_total != EXPECTED_C1_TOTAL:
        warnings.append({'type':'c1TotalMismatch','expected':EXPECTED_C1_TOTAL,'actual':c1_total})
    if c2_total != EXPECTED_C2_TOTAL:
        warnings.append({'type':'c2TotalMismatch','expected':EXPECTED_C2_TOTAL,'actual':c2_total})
    if key_total != EXPECTED_KEY_TOTAL:
        warnings.append({'type':'keyTotalMismatch','expected':EXPECTED_KEY_TOTAL,'actual':key_total})
    if set(c1_counts) != set(range(1, 11)):
        warnings.append({'type':'chapterSetMismatch','actual':sorted(c1_counts)})

    for ch in range(1,11):
        if key_counts[ch] != 35:
            warnings.append({'type':'keyCountMismatch','chapter':ch,'expected':35,'actual':key_counts[ch]})
        if c2_counts[ch] != 18:
            warnings.append({'type':'c2ChapterCountMismatch','chapter':ch,'expected':18,'actual':c2_counts[ch]})
        header_expected = HEADER_C1_COUNTS[ch]
        if c1_counts[ch] != header_expected:
            warnings.append({
                'type':'chapterHeaderCountMismatch',
                'chapter':ch,
                'headerDeclared':header_expected,
                'extracted':c1_counts[ch]
            })

    ids = [e['id'] for e in entries]
    if len(ids) != len(set(ids)):
        warnings.append({'type':'duplicateIds','count':len(ids)-len(set(ids))})

    empty_german = [e['id'] for e in entries if not e['german']]
    empty_en = [e['id'] for e in entries if not e['english']]
    empty_zh = [e['id'] for e in entries if not e['traditionalChinese']]
    if empty_german:
        warnings.append({'type':'missingGerman','count':len(empty_german),'ids':empty_german[:20]})
    if empty_en:
        warnings.append({'type':'missingEnglish','count':len(empty_en),'ids':empty_en[:20]})
    if empty_zh:
        warnings.append({'type':'missingTraditionalChinese','count':len(empty_zh),'ids':empty_zh[:20]})

    chapters = []
    for ch in range(1,11):
        chapters.append({
            'chapter': ch,
            'c1Entries': c1_counts[ch],
            'c1KeyEntries': key_counts[ch],
            'c2UpgradeEntries': c2_counts[ch],
            'totalEntries': c1_counts[ch] + c2_counts[ch],
            'pdfHeaderDeclaredC1Entries': HEADER_C1_COUNTS[ch],
        })

    dataset = {
        'schemaVersion': '1.0.0',
        'source': {
            'filename': SOURCE.name,
            'title': 'Aspekte neu C1 · Complete Vocabulary Study Edition',
            'languages': ['de', 'en', 'zh-TW'],
            'notes': [
                'C1 entries preserve sourceReference codes when present.',
                'The 350 C1 key items are detected from the PDF light-gray vector background.',
                'C2 Upgrade entries are assigned to their corresponding Kapitel as printed in the PDF.',
                'One C1 entry is explicitly printed under “Ohne Kapitelangabe” and therefore has chapter=null rather than being guessed into Kapitel 10.',
                'rawText preserves extracted source block text; cleaned fields normalize only explicit layout artifacts listed by the converter.'
            ],
        },
        'summary': {
            'chapters': 10,
            'c1Entries': c1_total,
            'c1EntriesAssignedToKapitel': sum(c1_counts.values()),
            'c1EntriesWithoutKapitel': c1_unassigned,
            'c1KeyEntries': key_total,
            'c2UpgradeEntries': c2_total,
            'allEntries': len(entries),
        },
        'chapters': chapters,
        'entries': entries,
    }

    report = {
        'source': SOURCE.name,
        'validationPassedForCoreTotals': (
            c1_total == EXPECTED_C1_TOTAL and
            c2_total == EXPECTED_C2_TOTAL and
            key_total == EXPECTED_KEY_TOTAL and
            all(c2_counts[ch] == 18 for ch in range(1,11)) and
            all(key_counts[ch] == 35 for ch in range(1,11)) and
            all(c1_counts[ch] == HEADER_C1_COUNTS[ch] for ch in range(1,11)) and
            c1_unassigned == 1 and
            len(ids) == len(set(ids)) and
            not empty_german and not empty_en and not empty_zh
        ),
        'expected': {
            'c1Entries': EXPECTED_C1_TOTAL,
            'c1KeyEntries': EXPECTED_KEY_TOTAL,
            'c2UpgradeEntries': EXPECTED_C2_TOTAL,
            'chapters': EXPECTED_CHAPTERS,
        },
        'actual': {
            'c1Entries': c1_total,
            'c1EntriesAssignedToKapitel': sum(c1_counts.values()),
            'c1EntriesWithoutKapitel': c1_unassigned,
            'c1KeyEntries': key_total,
            'c2UpgradeEntries': c2_total,
            'allEntries': len(entries),
            'chapters': len(c1_counts),
            'c1ByChapter': {str(k): c1_counts[k] for k in range(1,11)},
            'keyByChapter': {str(k): key_counts[k] for k in range(1,11)},
            'c2ByChapter': {str(k): c2_counts[k] for k in range(1,11)},
        },
        'dataQuality': {
            'entriesWithExamples': sum(bool(e['examplesGerman']) for e in entries),
            'exampleSentenceCount': sum(len(e['examplesGerman']) for e in entries),
            'entriesWithChunks': sum(bool(e['chunks']) for e in entries),
            'chunkCount': sum(len(e['chunks']) for e in entries),
            'entriesWithExplicitFormenLine': sum(bool(e['formsRaw']) for e in entries),
            'entriesMissingSourceReference': sum(1 for e in entries if e['level']=='C1' and not e['sourceReference']),
            'entriesExplicitlyWithoutKapitel': c1_unassigned,
            'missingEnglish': len(empty_en),
            'missingTraditionalChinese': len(empty_zh),
        },
        'warnings': warnings,
        'needsReview': needs_review,
        'explicitLayoutArtifactFixes': LAYOUT_ARTIFACT_FIXES,
    }

    OUT.write_text(json.dumps(dataset, ensure_ascii=False, indent=2), encoding='utf-8')
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')

    print(json.dumps(report, ensure_ascii=False, indent=2))
    print(f'Wrote {OUT} ({OUT.stat().st_size:,} bytes)')
    print(f'Wrote {REPORT} ({REPORT.stat().st_size:,} bytes)')

if __name__ == '__main__':
    main()
